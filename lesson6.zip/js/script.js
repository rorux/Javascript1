// Задание 1

function bigPic(e) {
    var bigPicture = document.querySelector(".big-picture img");
    bigPicture.src = e.target.dataset.picture;
    bigPicture.onerror = function () {
        alert("Ошибка во время загрузки изображения");
        bigPicture.src = "img/empty-big.jpg";
    };
}

var img = document.querySelectorAll(".small-pictures img");

for (var item of img) {
    item.onclick = bigPic;
}


// Задание 2

function itemToCart(e) {
    // получаем индекс товара в массиве goods
    var idItem = e.target.id.replace("item", "");

    if (!cartShow.length) { // если в корзине пусто
        var itemCartObj = {
            id: idItem,
            title: goods[idItem].title,
            price: goods[idItem].price,
            quantity: 1,
            cost: goods[idItem].price
        }

        IdItemsCart.push(idItem); // добавляем в массив ID товара
        cartShow.push(itemCartObj); // добавляем в массив корзины объект
        cartShowEcho(cartShow); // вывод товаров в корзине
    }
    else { // если в корзине уже лежат товары

        // счетчик для проверки, новый товар добавляется в корзину или нет
        var checkCartId = 0;

        // добавляем товары, которые уже ранее положены в корзину
        for (var ItemId in cartShow) {
            // если в корзине уже лежит товар
            if (cartShow[ItemId].id == idItem) {
                (cartShow[ItemId].quantity)++;
                cartShow[ItemId].cost += cartShow[ItemId].price;
                cartShowEcho(cartShow);
                checkCartId++;
            }
        }

        // добавляем новый объект в массив cartShow (если счетчик показал, что добавляется новый товар)
        if (!checkCartId) {
            var itemCartObj = {
                id: idItem,
                title: goods[idItem].title,
                price: goods[idItem].price,
                quantity: 1,
                cost: goods[idItem].price
            }

            IdItemsCart.push(idItem);
            cartShow.push(itemCartObj);
            cartShowEcho(cartShow);
        }

    }

}

function cartShowEcho(cartShow) {
    var cartLoad = document.getElementById("cart-show");
    cartLoad.innerText = "";

    var divWrap = document.createElement("div");
    divWrap.className = "cart-text";

    // Подсчет итоговой суммы в корзине
    var ResultSum = 0;

    for (var item of cartShow) {

        ResultSum += parseInt(item.cost);

        divItem = document.createElement("div");
        divItem.className = "cart-text-item";
        divItem.id = "cart" + item.id;

        spanTitle = document.createElement("span");
        spanTitle.className = "cart-text-item-title";
        spanTitle.innerText = item.title;

        divItem.append(spanTitle);

        spanCount = document.createElement("span");
        spanCount.className = "cart-text-item-count";
        spanCount.innerText = " (" + item.quantity + " шт.) - ";

        divItem.append(spanCount);

        spanCost = document.createElement("span");
        spanCost.className = "cart-text-item-cost";
        spanCost.innerText = item.cost + " руб.";

        divItem.append(spanCost);

        divWrap.append(divItem);
    }

    cartLoad.append(divWrap);

    cartResult = document.createElement("div");
    cartResult.className = "cart-text-result";
    cartResult.innerText = ResultSum + " руб.";

    divItem.append(cartResult);

}

var goods = [

    {
        title: "Apple iPhone SE 2020 64GB",
        price: 39990
    },
    {
        title: "Apple iPhone 11 Pro 256GB",
        price: 96990
    },
    {
        title: "Apple iPhone 7 32GB",
        price: 26990
    }

];

// пустая корзина
var cartShow = [];

// какие товары в корзине (id)
var IdItemsCart = [];

var itemBuy = document.querySelectorAll(".items .item .item-buy");

for (var item of itemBuy) {
    item.onclick = itemToCart;
}


// Задание 3

function imgSrc() {
    // вытаскиваем номер текущей картинки
    var matches = document.querySelector("#slider").src.match(/img\/(\d+)\-big\.jpg/);
    return matches[1];
}

// максимальный номер изображения
var SliderImg = 3;

var switchLeft = document.querySelector(".switch-left");
var switchRight = document.querySelector(".switch-right");

switchLeft.onclick = function () {
    var nmbImgNow = imgSrc();
    if (nmbImgNow == 1) {
        document.querySelector("#slider").src = "img/" + SliderImg + "-big.jpg"
    }
    else {
        nmbImgNow--;
        document.querySelector("#slider").src = "img/" + nmbImgNow + "-big.jpg"
    }
}

switchRight.onclick = function () {
    var nmbImgNow = imgSrc();
    if (nmbImgNow == SliderImg) {
        document.querySelector("#slider").src = "img/1-big.jpg"
    }
    else {
        nmbImgNow++;
        document.querySelector("#slider").src = "img/" + nmbImgNow + "-big.jpg"
    }
}











